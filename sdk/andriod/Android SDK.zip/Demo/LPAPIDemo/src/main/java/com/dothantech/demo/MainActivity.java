package com.dothantech.demo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.dothantech.lpapi.LPAPI;
import com.dothantech.lpapi.LPAPI.BarcodeType;
import com.dothantech.printer.IDzPrinter;
import com.dothantech.printer.IDzPrinter.PrintParamName;
import com.dothantech.printer.IDzPrinter.PrintProgress;
import com.dothantech.printer.IDzPrinter.PrinterAddress;
import com.dothantech.printer.IDzPrinter.PrinterState;
import com.dothantech.printer.IDzPrinter.ProgressInfo;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@SuppressLint("InflateParams")
public class MainActivity extends Activity {

    private LPAPI api;

    // 用于处理各种通知消息，刷新界面的handler
    private final Handler mHandler = new Handler();

    // 需要用到的各个控件对象
    private Button btnConnectDevice = null;
    private Button btnGapType = null;
    private Button btnGapLength = null;
    private Button btnPrintDensity = null;
    private Button btnPrintSpeed = null;
    private EditText et1 = null;
    private EditText et2 = null;

    // 打印参数
    private int gapType = -1;
    private int gapLength = 3;
    private int printDensity = -1;
    private int printSpeed = -1;

    // 打印数据
    private String defaultText1 = "上海道臻信息技术有限公司\nDzPrinterDemo";
    private String defaultText2 = "上海道臻信息技术有限公司\nDzPrinterDemo";
    private String default1dBarcode = "1234567890";
    private String default2dBarcode = "http://www.dothantech.com/";

    // 用于填充的数组及集合列表
    private final String[] printDensityList = new String[]{"随打印机设置", "1 (最淡)", "2", "3 (较淡)", "4", "5", "6 (正常)", "7", "8", "9", "10", "11", "12(较深)", "13", "14", "15", "16", "17", "18", "19", "20(最深)",};
    private final String[] printSpeedList = new String[]{"随打印机设置", "1 (最慢)", "2 (较慢)", "3 (正常)", "4 (较快)", "5 (最快)",};
    private final String[] gapTypeList = new String[]{"随打印机设置", "连续纸", "定位孔", "间隙纸", "黑标纸",};
    private final int[] bitmapOrientations = new int[]{0, 90, 0, 90,};

    private final List<Bitmap> printBitmaps = new ArrayList<>();

    // 状态提示框
    private AlertDialog stateAlertDialog = null;
    // 打印机弹窗
    private DeviceListAdapter printerAdapter = null;
    private List<PrinterAddress> discoveredPrinterList = null;

    //********************************************************************************************************************************************
    // DzPrinter连接打印功能相关
    //********************************************************************************************************************************************

    // LPAPI 打印机操作相关的回调函数。
    private final LPAPI.Callback mCallback = new LPAPI.Callback() {

        //****************************************************************************************************************************************
        // 所有回调函数都是在打印线程中被调用，因此如果需要刷新界面，需要发送消息给界面主线程，以避免互斥等繁琐操作。
        //****************************************************************************************************************************************

        // 打印机连接状态发生变化时被调用
        @Override
        public void onStateChange(PrinterAddress arg0, PrinterState arg1) {
            final PrinterAddress printer = arg0;
            Log.e("aa", "state = " + arg1);
            switch (arg1) {
                case Connected:
                case Connected2:
                    // 打印机连接成功，发送通知，刷新界面提示
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            onPrinterConnected(printer);
                        }
                    });
                    break;

                case Disconnected:
                    // 打印机连接失败、断开连接，发送通知，刷新界面提示
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            onPrinterDisconnected();
                        }
                    });
                    break;

                default:
                    break;
            }
        }

        // 蓝牙适配器状态发生变化时被调用
        @Override
        public void onProgressInfo(ProgressInfo arg0, Object arg1) {
        }

        @Override
        public void onPrinterDiscovery(PrinterAddress printerAddress, Object o) {
            // TODO 这个回调函数里接受到搜素到的打印机
            onPrinterDiscovered(printerAddress);
        }

        // 打印标签的进度发生变化是被调用
        @Override
        public void onPrintProgress(PrinterAddress address, IDzPrinter.PrintData bitmapData, PrintProgress progress, Object addiInfo) {
            switch (progress) {
                case Success:
                    // 打印标签成功，发送通知，刷新界面提示
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            onPrintSuccess();
                        }
                    });
                    break;

                case Failed:
                    // 打印标签失败，发送通知，刷新界面提示
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            onPrintFailed();
                        }
                    });
                    break;

                default:
                    break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // 初始化界面
        initialView();

        // 调用LPAPI对象的init方法初始化对象
        this.api = LPAPI.Factory.createInstance(mCallback);
        // 请求权限
        requestPermission();
    }

    @Override
    protected void onDestroy() {
        // 应用退出时，调用LPAPI对象的quit方法断开打印机连接
        api.quit();
        super.onDestroy();
    }

    // 打印机列表的每项点击事件
    private class DeviceListItemClicker implements OnClickListener {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            api.stopDiscovery();
            PrinterAddress printer = discoveredPrinterList.get(which);
            if (printer != null) {
                String printerName = api.getPrinterName();

                if (api.getPrinterState().group() == 2 && TextUtils.equals(printerName, printer.shownName)) {
                    // TODO 如果再次点击当前连接的打印机，可以断开，可以忽略点击事件，但是不能再次代码连接这个打印机。
                    Toast.makeText(MainActivity.this, "当前打印机已连接", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    // 连接选择的打印机
                    if (api.openPrinterByAddress(printer)) {
                        // 连接打印机的请求提交成功，刷新界面提示
                        onPrinterConnecting(printer, true);
                        return;
                    }
                }
            }

            // 连接打印机失败，刷新界面提示
            onPrinterDisconnected();
        }
    }

    // 判断当前打印机是否连接
    private boolean isPrinterConnected() {
        // 调用LPAPI对象的getPrinterState方法获取当前打印机的连接状态
        PrinterState state = api.getPrinterState();

        // 打印机未连接
        if (state == null || state.equals(PrinterState.Disconnected)) {
            Toast.makeText(MainActivity.this, "打印机未连接，请先连接打印机！", Toast.LENGTH_SHORT).show();
            return false;
        }

        // 打印机正在连接
        if (state.equals(PrinterState.Connecting)) {
            Toast.makeText(MainActivity.this, "正在连接打印机，请稍候！", Toast.LENGTH_SHORT).show();
            return false;
        }

        // 打印机已连接
        return true;
    }

    // 获取打印时需要的打印参数，不设置就默认跟随打印机设置
    private Bundle getPrintParam(int copies, int orientation) {
        Bundle param = new Bundle();

        // 间隔类型
        if (gapType >= 0) {
            param.putInt(PrintParamName.GAP_TYPE, gapType);
        }
        // 间隔长度
        if (gapLength >= 0) {
            param.putInt(PrintParamName.GAP_LENGTH, gapLength);
        }
        // 打印浓度
        if (printDensity >= 0) {
            param.putInt(PrintParamName.PRINT_DENSITY, printDensity);
        }

        // 打印速度
        if (printSpeed >= 0) {
            param.putInt(PrintParamName.PRINT_SPEED, printSpeed);
        }

        // 打印页面旋转角度
        if (orientation != 0) {
            param.putInt(PrintParamName.PRINT_DIRECTION, orientation);
        }

        // 打印份数
        if (copies > 1) {
            param.putInt(PrintParamName.PRINT_COPIES, copies);
        }

        return param;
    }

    //********************************************************************************************************************************************
    // LPAPI绘图打印相关
    //********************************************************************************************************************************************

    // 打印文本
    private boolean printText(String text) {
        // 开始绘图任务，传入参数(页面宽度, 页面高度)
        api.startJob(48, 50, 0);

        // 开始一个页面的绘制，绘制文本字符串
        // 传入参数(需要绘制的文本字符串, 绘制的文本框左上角水平位置, 绘制的文本框左上角垂直位置, 绘制的文本框水平宽度, 绘制的文本框垂直高度, 文字大小, 字体风格)
        api.drawText(text, 4, 5, 40, 40, 4);

        // 结束绘图任务提交打印(跟随打印机设置，无特殊需求，推荐使用此种方式)
        return api.commitJob();
    }

    // 打印文本一维码
    private List<Bitmap> printText1DBarcode(String text, String onedBarcde) {

        // 开始绘图任务，传入参数(页面宽度, 页面高度)
        api.startJob(48, 48, 90);

        // 开始一个页面的绘制，绘制文本字符串
        // 传入参数(需要绘制的文本字符串, 绘制的文本框左上角水平位置, 绘制的文本框左上角垂直位置, 绘制的文本框水平宽度, 绘制的文本框垂直高度, 文字大小, 字体风格)
        api.drawText(text, 4, 4, 40, 20, 4);

        // 设置之后绘制的对象内容旋转180度
        api.setItemOrientation(180);

        // 绘制一维码，此一维码绘制时内容会旋转180度，
        // 传入参数(需要绘制的一维码的数据, 绘制的一维码左上角水平位置, 绘制的一维码左上角垂直位置, 绘制的一维码水平宽度, 绘制的一维码垂直高度)
        api.draw1DBarcode(onedBarcde, BarcodeType.AUTO, 4, 25, 40, 15, 3);

        // 结束绘图任务
        api.endJob();

        // 获取已结束的任务页面图片数据
        return api.getJobPages();
    }

    // 打印二维码
    private boolean print2dBarcode(String twodBarcode, Bundle param) {
        // 开始绘图任务，传入参数(页面宽度, 页面高度)
        api.startJob(48, 50, 0);

        // 开始一个页面的绘制，绘制二维码
        // 传入参数(需要绘制的二维码的数据, 绘制的二维码左上角水平位置, 绘制的二维码左上角垂直位置, 绘制的二维码的宽度(宽高相同))
        api.draw2DQRCode(twodBarcode, 9, 10, 30);

        // 结束绘制任务提交打印(打印时的打印质量、间隔类型、打印浓度和打印速度适用应用中配置的值)
        return api.commitJobWithParam(param);
    }

    // 打印图片
    private boolean printBitmap(Bitmap bitmap, Bundle param) {
        // 打印
        return api.printBitmap(bitmap, param);
    }

    //********************************************************************************************************************************************
    // 应用界面相关
    //********************************************************************************************************************************************

    // 初始化界面
    private void initialView() {
        String[] testPicName = new String[]{"test1.png", "test2.png", "test3.png", "test4.png",};

        btnConnectDevice = findViewById(R.id.btn_printer);
        btnGapType = findViewById(R.id.btn_gaptype);
        btnGapLength = findViewById(R.id.btn_gaplength);
        btnPrintDensity = findViewById(R.id.btn_printdensity);
        btnPrintSpeed = findViewById(R.id.btn_printspeed);
        refreshPrintParamView();

        // 加载测试用图片文件
        for (String str : testPicName) {
            try {
                InputStream is = getAssets().open(str);
                Bitmap bmp = BitmapFactory.decodeStream(is);
                if (bmp != null) {
                    printBitmaps.add(bmp);
                }
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }

    // 选择打印机的按钮事件
    public void selectPrinterOnClick(View view) {
        BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
        if (btAdapter == null) {
            Toast.makeText(MainActivity.this, "当前设备不支持蓝牙！", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!btAdapter.isEnabled()) {
            Toast.makeText(MainActivity.this, "蓝牙适配器未开启！", Toast.LENGTH_SHORT).show();
            return;
        }
        // TODO 开始搜索打印机
        api.discovery();
        discoveredPrinterList = new ArrayList<>();
        new AlertDialog.Builder(MainActivity.this).setTitle("选择搜索到的设备").setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                api.stopDiscovery();
            }
        }).setAdapter(printerAdapter = new DeviceListAdapter(MainActivity.this), new DeviceListItemClicker()).show();
    }

    // 设置间隔类型的按钮事件
    public void gapTypeOnClick(View view) {
        new AlertDialog.Builder(MainActivity.this).setTitle("设置间隔类型").setAdapter(new PrintParamAdapter(MainActivity.this, gapTypeList), new GapTypeItemClicker()).show();
    }

    // 设置打印质量的按钮事件
    public void gapLengthOnClick(View view) {
        if (!isPrinterConnected()) {
            Toast.makeText(MainActivity.this, "请先连接打印机", Toast.LENGTH_LONG).show();
            return;
        }
        // 显示打印数据设置界面
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("设置间隔长度（跳距）");
        builder.setView(initView("间隔长度：", String.valueOf(gapLength)));
        builder.setPositiveButton("确定", new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 获取打印数据并进行打印
                String length = et1.getText().toString();
                try {
                    gapLength = Integer.parseInt(length);
                } catch (Throwable e) {
                    e.printStackTrace();
                }
                btnGapLength.setText("间隔长度：\n" + gapLength);
                api.setPrintPageGapLength(gapLength);
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }

    // 设置打印浓度的按钮事件
    public void printDensityOnClick(View view) {
        if (!isPrinterConnected()) {
            Toast.makeText(MainActivity.this, "请先连接打印机", Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(MainActivity.this).setTitle("设置打印浓度").setAdapter(new PrintParamAdapter(MainActivity.this, printDensityList), new PrintDensityItemClicker()).show();
    }

    // 设置打印速度的按钮事件
    public void printSpeedOnClick(View view) {
        if (!isPrinterConnected()) {
            Toast.makeText(MainActivity.this, "请先连接打印机", Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(MainActivity.this).setTitle("设置打印速度").setAdapter(new PrintParamAdapter(MainActivity.this, printSpeedList), new PrintSpeedItemClicker()).show();
    }

    // 打印文本的按钮事件
    public void printTextOnClick(View view) {
        // 显示打印数据设置界面
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("打印文本");
        builder.setView(initView("文本数据：", defaultText1));
        builder.setPositiveButton("确定", new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 获取打印数据并进行打印
                defaultText1 = et1.getText().toString();
                if (isPrinterConnected()) {
                    if (printText(defaultText1)) {
                        onPrintStart();
                    } else {
                        onPrintFailed();
                    }
                }
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }

    // 打印文本一维码的按钮事件
    public void printText1DBarcodeOnClick(View view) {
        // 显示打印数据设置界面
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("文本一维码");
        builder.setView(init1DBarcodeParamView(defaultText2, default1dBarcode));
        builder.setPositiveButton("确定", new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 获取打印数据并进行打印
                defaultText2 = et1.getText().toString();
                default1dBarcode = et2.getText().toString();
                if (isPrinterConnected()) {
                    List<Bitmap> bitmaps = printText1DBarcode(defaultText1, default1dBarcode);
                    if (null != bitmaps && bitmaps.size() > 0) {
                        showPreviewBitmapDialog(bitmaps.get(0));
                    }
                }
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }

    // 打印二维码的按钮事件
    public void print2DBarcodeOnClick(View view) {
        // 显示打印数据设置界面
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("打印二维码");
        builder.setView(initView("二维码数据：", default2dBarcode));
        builder.setPositiveButton("确定", new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 获取打印数据并进行打印
                default2dBarcode = et1.getText().toString();
                if (isPrinterConnected()) {
                    if (print2dBarcode(default2dBarcode, getPrintParam(1, 0))) {
                        onPrintStart();
                    } else {
                        onPrintFailed();
                    }
                }
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }

    // 打印图片的按钮事件
    public void printBitmapOnClick(View view) {
        new AlertDialog.Builder(MainActivity.this).setTitle("打印图片").setAdapter(new BitmapListAdapter(MainActivity.this, printBitmaps), new BitmapListItemClicker()).show();
    }

    // 打印自定义模板，样式如下：
    /*
     * --------------------------------------------------
     * |                玄码科技固定资产                |
     * --------------------------------------------------
     * |资产编码 | 1234567890123456789                  |
     * --------------------------------------------------
     * |资产名称 | 笔记本电脑                           |
     * --------------------------------------------------
     * |使用人   | 张三                  |              |
     * ----------------------------------      二维码
     * |购买日期 | 2025年10月17日        |              |
     * --------------------------------------------------
     */
    public void printLabelOnClick(View view) {
        double labelWidth = 60;                                                 // 模板宽
        double labelHeight = 40;                                                // 模板高
        double marginOut = 2;                                                   // 表格外边距
        double marginIn = 0.5;                                                  // 表格单元格内边距
        double tableWidth = labelWidth - marginOut * 2;                         // 表格宽
        double tableHeight = labelHeight - marginOut * 2;                       // 表格高
        double tableRowHeight = tableHeight / 5;                                // 表格行高
        double tableColWidth3 = tableRowHeight * 2;                             // 表格第三列列宽
        double tableColWidth1 = 15;                                             // 表格第一列列宽
        double tableColWidth2 = tableWidth - tableColWidth3 - tableColWidth1;   // 表格第二列列宽
        int rotation = 90;                                                      // 最终打印时的顺时针旋转角度。
        double lineWidth = 0.5;                                                 // 线条宽度
        boolean shownLine = true;                                               // 是否显示表格的线条和外边框
        double fontSize = 3.5;                                                  // 字体大小（单位mm）
        double qrcodeWidth = tableRowHeight * 2 - 3;                           // 二维码宽高

        // 开始打印任务
        api.startJob(labelWidth, labelHeight, rotation);
        if (shownLine) {
            // 绘制矩形
            api.drawRectangle(marginOut, marginOut, tableWidth, tableHeight, lineWidth);
            // 绘制表格的内部线条
            // 横线
            api.drawLine(marginOut, marginOut + tableRowHeight * 1, labelWidth - marginOut - lineWidth * 0.5, marginOut + tableRowHeight * 1, lineWidth);
            api.drawLine(marginOut, marginOut + tableRowHeight * 2, labelWidth - marginOut - lineWidth * 0.5, marginOut + tableRowHeight * 2, lineWidth);
            api.drawLine(marginOut, marginOut + tableRowHeight * 3, labelWidth - marginOut - lineWidth * 0.5, marginOut + tableRowHeight * 3, lineWidth);
            api.drawLine(marginOut, marginOut + tableRowHeight * 4, labelWidth - marginOut - lineWidth * 0.5 - tableColWidth3, marginOut + tableRowHeight * 4, lineWidth);
            // 竖线
            api.drawLine(marginOut + tableColWidth1, marginOut + tableRowHeight * 1, marginOut + tableColWidth1, labelHeight - marginOut - lineWidth * 0.5, lineWidth);
            api.drawLine(marginOut + tableColWidth1 + tableColWidth2, marginOut + tableRowHeight * 3, marginOut + tableColWidth1 + tableColWidth2, labelHeight - marginOut - lineWidth * 0.5, lineWidth);
        }
        // 后面的绘制文本都在设定的绘制区域内水平居中（不设置就默认居左）
        api.setItemHorizontalAlignment(1);
        // 后面的绘制文本都在设定的绘制区域内水平居中（不设置就默认居上）
        api.setItemVerticalAlignment(1);
        // 标题（字体加粗）
        api.drawTextRegular("玄码科技固定资产", marginOut + marginIn, marginOut + marginIn, tableWidth - marginIn * 2, tableRowHeight - marginIn * 2, fontSize, 1);
        // 绘制左侧小标题(字体不加粗)
        double cellContentWidth = tableColWidth1 - marginIn * 2; // 标题文本宽度
        double cellContentHeight = tableRowHeight - marginIn * 2; // 标题文本高度
        api.drawTextRegular("资产编码", marginOut + marginIn, marginOut + marginIn + tableRowHeight * 1, cellContentWidth, cellContentHeight, fontSize, 0);
        api.drawTextRegular("资产名称", marginOut + marginIn, marginOut + marginIn + tableRowHeight * 2, cellContentWidth, cellContentHeight, fontSize, 0);
        api.drawTextRegular("使用人", marginOut + marginIn, marginOut + marginIn + tableRowHeight * 3, cellContentWidth, cellContentHeight, fontSize, 0);
        api.drawTextRegular("购买日期", marginOut + marginIn, marginOut + marginIn + tableRowHeight * 4, cellContentWidth, cellContentHeight, fontSize, 0);
        // 绘制小标题对应的内容（字体不加粗）
        api.setItemHorizontalAlignment(0); // 后面的绘制文本都在设定的绘制区域内水平居左
        double cellContentWidth1 = tableWidth - tableColWidth1 - marginIn * 2;
        double cellContentWidth2 = tableColWidth2 - marginIn * 2;
        api.drawTextRegular("1234567890123456789", marginOut + tableColWidth1 + marginIn, marginOut + marginIn + tableRowHeight * 1, cellContentWidth1, cellContentHeight, fontSize, 0);
        api.drawTextRegular("笔记本电脑", marginOut + tableColWidth1 + marginIn, marginOut + marginIn + tableRowHeight * 2, cellContentWidth1, cellContentHeight, fontSize, 0);
        api.drawTextRegular("张三", marginOut + tableColWidth1 + marginIn, marginOut + marginIn + tableRowHeight * 3, cellContentWidth2, cellContentHeight, fontSize, 0);
        api.drawTextRegular("2025年10月17日", marginOut + tableColWidth1 + marginIn, marginOut + marginIn + tableRowHeight * 4, cellContentWidth2, cellContentHeight, fontSize, 0);
        // 绘制二维码
        api.draw2DQRCode("二维码内容", labelWidth - marginOut - qrcodeWidth - 1.5, labelHeight - marginOut - qrcodeWidth - 1.5, qrcodeWidth);
        api.commitJob();
    }

    // 刷新各按钮的显示内容
    private void refreshPrintParamView() {
        btnConnectDevice.setText("");
        btnGapType.setText("间隔类型：\n" + gapTypeList[gapType + 1]);
        btnGapLength.setText("间隔长度：\n" + gapLength);
        btnPrintDensity.setText("打印浓度：\n" + printDensityList[printDensity + 1]);
        btnPrintSpeed.setText("打印速度：\n" + printSpeedList[printSpeed + 1]);
    }

    // 显示打印预览图片
    private void showPreviewBitmapDialog(final Bitmap bitmap) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("打印预览");
        ImageView imageView = new ImageView(MainActivity.this);
        if (null != bitmap) {
            imageView.setImageBitmap(bitmap);
        }
        builder.setView(imageView);
        builder.setPositiveButton("确定", new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                api.printBitmap(bitmap, null);
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }

    // 连接打印机请求成功提交时操作
    private void onPrinterConnecting(PrinterAddress printer, boolean showDialog) {
        // 连接打印机请求成功提交，刷新界面提示
        String txt = printer.shownName;
        if (TextUtils.isEmpty(txt)) {
            txt = printer.macAddress;
        }
        txt = String.format("正在连接[%s]打印机", txt);
        if (showDialog) {
            showStateAlertDialog(txt);
        }
        btnConnectDevice.setText(txt);
    }

    // 连接打印机成功时操作
    private void onPrinterConnected(PrinterAddress printer) {
        // 连接打印机成功时，刷新界面提示，保存相关信息
        clearAlertDialog();
        Toast.makeText(MainActivity.this, "连接打印机成功！", Toast.LENGTH_SHORT).show();
        // 调用LPAPI对象的getPrinterInfo方法获得当前连接的打印机信息
        String txt = "打印机：";
        txt += api.getPrinterInfo().deviceName + "\n";
        txt += api.getPrinterInfo().deviceAddress;
        btnConnectDevice.setText(txt);
    }

    // 连接打印机操作提交失败、打印机连接失败或连接断开时操作
    private void onPrinterDisconnected() {
        // 连接打印机操作提交失败、打印机连接失败或连接断开时，刷新界面提示
        clearAlertDialog();

        Toast.makeText(MainActivity.this, "连接打印机失败！", Toast.LENGTH_SHORT).show();
        // 打印机断开连接后，将之前设置的打印机参数恢复为默认值
        gapType = -1;
        gapLength = 3;
        printDensity = -1;
        printSpeed = -1;
        refreshPrintParamView();
    }

    // 开始打印标签时操作
    private void onPrintStart() {
        // 开始打印标签时，刷新界面提示
        showStateAlertDialog("正在打印标签...");
    }

    // 标签打印成功时操作
    private void onPrintSuccess() {
        // 标签打印成功时，刷新界面提示
        clearAlertDialog();
        Toast.makeText(MainActivity.this, "标签打印成功！", Toast.LENGTH_SHORT).show();
    }

    // 打印请求失败或标签打印失败时操作
    private void onPrintFailed() {
        // 打印请求失败或标签打印失败时，刷新界面提示
        clearAlertDialog();
        Toast.makeText(MainActivity.this, "标签打印失败！", Toast.LENGTH_SHORT).show();
    }

    // 显示连接、打印的状态提示框
    private void showStateAlertDialog(String str) {
        if (stateAlertDialog != null && stateAlertDialog.isShowing()) {
            stateAlertDialog.setTitle(str);
        } else {
            stateAlertDialog = new AlertDialog.Builder(MainActivity.this).setCancelable(false).setTitle(str).show();
        }
    }

    // 清除连接、打印的状态提示框
    private void clearAlertDialog() {
        if (stateAlertDialog != null && stateAlertDialog.isShowing()) {
            stateAlertDialog.dismiss();
        }
        stateAlertDialog = null;
    }

    private void onPrinterDiscovered(PrinterAddress address) {
        if (null == address) {
            return;
        }

        if (null == discoveredPrinterList) {
            discoveredPrinterList = new ArrayList<>();
        } else {
            List<PrinterAddress> list = new ArrayList<>(discoveredPrinterList);
            for (PrinterAddress address1 : list) {
                // 如果搜索到的打印机列表中已经存在该打印机，可以替换给新的，也可以直接返回
                if (null != address1 && TextUtils.equals(address1.shownName, address.shownName)) {
                    return;
                }
            }
        }

        discoveredPrinterList.add(address);
        new Handler(getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                printerAdapter.setData(discoveredPrinterList);
                printerAdapter.notifyDataSetChanged();
            }
        });
    }

    // 设置打印浓度的每项点击事件
    private class PrintDensityItemClicker implements OnClickListener {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            printDensity = which - 1;
            btnPrintDensity.setText("打印浓度：\n" + printDensityList[which]);
            api.setPrintDarkness(printDensity);
        }
    }

    // 设置打印速度的每项点击事件
    private class PrintSpeedItemClicker implements OnClickListener {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            printSpeed = which - 1;
            btnPrintSpeed.setText("打印速度：\n" + printSpeedList[which]);
            api.setPrintSpeed(printSpeed);
        }
    }

    // 设置间隔类型的每项点击事件
    private class GapTypeItemClicker implements OnClickListener {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            gapType = which - 1;
            btnGapType.setText("间隔类型：\n" + gapTypeList[which]);
            api.setPrintPageGapType(gapType);
        }
    }

    // 打印图片的示例图片列表的每项点击事件
    private class BitmapListItemClicker implements OnClickListener {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            if (isPrinterConnected()) {
                int orientation = 0;
                if (bitmapOrientations.length > which) {
                    orientation = bitmapOrientations[which];
                }

                // 获取打印数据并进行打印
                Bitmap bmp = printBitmaps.get(which);
                if (bmp != null) {
                    if (printBitmap(bmp, getPrintParam(1, orientation))) {
                        onPrintStart();
                        return;
                    }
                }

                onPrintFailed();
            }
        }
    }

    private void requestPermission() {
        // 请求权限
        String[] permissions = new String[]{
                Manifest.permission.BLUETOOTH,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                "android.permission.BLUETOOTH_SCAN",        // TODO android 12之后需要这两个权限，如果当前目标版本不到Android 12，可以用这两个字符串代替。如果还是无法搜索到打印机，就只能升级应用目标版本了
                "android.permission.BLUETOOTH_CONNECT"

        };
        requestPermissions(permissions, 0);
    }

    // 初始化并获得设置打印数据的界面（一项数据）
    private View initView(String title1, String text1) {
        View view = View.inflate(MainActivity.this, R.layout.setvalue_item, null);
        ((TextView) view.findViewById(R.id.tv_title1)).setText(title1);
        et1 = (EditText) view.findViewById(R.id.et_value1);
        et1.setText(text1 == null ? "" : text1);
        et1.setSelection(et1.getText().toString().length());
        return view;
    }

    // 初始化并获得设置打印数据的界面（两项数据）
    private View init1DBarcodeParamView(String text1, String text2) {
        View view = View.inflate(MainActivity.this, R.layout.setvalue_item, null);
        ((LinearLayout) view.findViewById(R.id.ll_2)).setVisibility(View.VISIBLE);
        ((TextView) view.findViewById(R.id.tv_title1)).setText("文本数据：");
        et1 = (EditText) view.findViewById(R.id.et_value1);
        et1.setText(text1 == null ? "" : text1);
        et1.setSelection(et1.getText().length());
        ((TextView) view.findViewById(R.id.tv_title2)).setText("一维码数据：");
        et2 = (EditText) view.findViewById(R.id.et_value2);
        et2.setText(text2 == null ? "" : text2);
        et2.setSelection(et2.getText().toString().length());
        return view;
    }

}
